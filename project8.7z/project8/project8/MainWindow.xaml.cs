﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace project8
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        List<double> dots = new List<double>();

        private void AcceptButton_Click(object sender, RoutedEventArgs e)
        {
            dots.Clear();
            try
            {
                double a = int.Parse(aTextBox.Text);
                double b = int.Parse(bTextBox.Text);
                double dot = 0;
                double dotsSum = 0;
                double h = (b - a) / b;
                double abFunctionSum = 0;
                double result = 0;
                dots.Add(a);
                for (int i = 1; i < b; i++)
                {
                    dot = dots[i-1] + h;
                    dots.Add(dot);
                }
                dots.Add(b);

                for (int i = 1; i < dots.Count - 1; i++)
                {
                    dotsSum += (Math.Pow(Math.Log10(dots[i]), 3) / dots[i]) + (Math.Pow(Math.Log10(dots[i + 1]), 3) / dots[i + 1]);
                }

                abFunctionSum = ((Math.Pow(Math.Log10(a), 3) / a) + (Math.Pow(Math.Log10(b), 3) / b))/2;

                result = h * (abFunctionSum + dotsSum);
                MessageBox.Show(result.ToString());

            }
            catch(Exception)
            {
                MessageBox.Show("Ошибка");
            }

        }
    }
}
